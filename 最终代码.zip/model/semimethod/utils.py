# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
from collections import OrderedDict

import torch


# from semilearn.algorithms.utils import concat_all_gather
# from semilearn.algorithms.hooks import MaskingHook


class SoftMatchWeightingHook():
    """
    SoftMatch learnable truncated Gaussian weighting
    """

    def __init__(self, num_classes, n_sigma = 2, momentum = 0.999, per_class = False, prob_max_mu_t = None,
                 prob_max_var_t = None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.num_classes = num_classes
        self.n_sigma = n_sigma
        self.per_class = per_class
        self.m = momentum
        self.prob_max_mu_t = prob_max_mu_t
        self.prob_max_var_t = prob_max_var_t

        # initialize Gaussian mean and variance
        if not self.per_class:
            self.prob_max_mu_t = torch.tensor(1.0 / self.num_classes)
            self.prob_max_var_t = torch.tensor(1.0)
        else:
            self.prob_max_mu_t = torch.ones((self.num_classes)) / self.num_classes
            self.prob_max_var_t = torch.ones((self.num_classes))

    @torch.no_grad()
    def update(self, algorithm, probs_x_ulb):
        # if algorithm.distributed and algorithm.world_size > 1:
        #     probs_x_ulb = concat_all_gather(probs_x_ulb)
        # 找到 probs_x_ulb 中每个样本在各个类别中的最大概率值 max_probs 和对应的类别索引 max_idx
        max_probs, max_idx = probs_x_ulb.max(dim = 1)
        if not self.per_class:  # 对所有类别的最大概率计算均值和方差
            prob_max_mu_t = torch.mean(max_probs)  # torch.quantile(max_probs, 0.5)
            prob_max_var_t = torch.var(max_probs, unbiased = True)
            # 使用指数衰减的方式来更新均值 mu 和方差 var
            self.prob_max_mu_t = self.m * self.prob_max_mu_t + (1 - self.m) * prob_max_mu_t.item()
            self.prob_max_var_t = self.m * self.prob_max_var_t + (1 - self.m) * prob_max_var_t.item()
        else:  # 分别计算每个类别的最大概率均值和方差
            prob_max_mu_t = torch.zeros_like(self.prob_max_mu_t)
            prob_max_var_t = torch.ones_like(self.prob_max_var_t)
            for i in range(self.num_classes):
                prob = max_probs[max_idx == i]
                if len(prob) > 1:
                    prob_max_mu_t[i] = torch.mean(prob)
                    prob_max_var_t[i] = torch.var(prob, unbiased = True)
            self.prob_max_mu_t = self.m * self.prob_max_mu_t + (1 - self.m) * prob_max_mu_t
            self.prob_max_var_t = self.m * self.prob_max_var_t + (1 - self.m) * prob_max_var_t
            # prob_max_mu_t = torch.zeros_like(self.prob_max_mu_t)
            # prob_max_var_t = torch.ones_like(self.prob_max_var_t)
            # for i in range(self.num_classes):
            #     prob = max_probs[:, i]  # Get max probabilities for class i over the batch dimension
            #     prob_max_mu_t[i] = torch.mean(prob)
            #     prob_max_var_t[i] = torch.var(prob, unbiased = True)
            # self.prob_max_mu_t = self.m * self.prob_max_mu_t + (1 - self.m) * prob_max_mu_t
            # self.prob_max_var_t = self.m * self.prob_max_var_t + (1 - self.m) * prob_max_var_t
        return max_probs, max_idx

    @torch.no_grad()
    def masking(self, algorithm, logits_x_ulb, softmax_x_ulb = True, *args, **kwargs):
        if not self.prob_max_mu_t.is_cuda:
            self.prob_max_mu_t = self.prob_max_mu_t.to(logits_x_ulb.device)
        if not self.prob_max_var_t.is_cuda:
            self.prob_max_var_t = self.prob_max_var_t.to(logits_x_ulb.device)

        if softmax_x_ulb:
            probs_x_ulb = torch.softmax(logits_x_ulb.detach(), dim = 1)
        else:
            # logits is already probs
            probs_x_ulb = logits_x_ulb.detach()

        self.update(algorithm, probs_x_ulb)  # 更新统计量

        # 找到 probs_x_ulb 中每个样本在各个类别中的最大概率值 max_probs 和对应的类别索引 max_idx，维度[batch_size, height, width]
        max_probs, max_idx = probs_x_ulb.max(dim = 1)
        # compute weight
        if not self.per_class:
            mu = self.prob_max_mu_t
            var = self.prob_max_var_t
        else:
            mu = self.prob_max_mu_t[max_idx]
            var = self.prob_max_var_t[max_idx]
        mask = torch.exp(-((torch.clamp(max_probs - mu, max = 0.0) ** 2) / (2 * var / (self.n_sigma ** 2))))
        return mask
