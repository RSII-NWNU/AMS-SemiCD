# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# from xml.sax.handler import feature_namespaces
import contextlib
import os
from collections import OrderedDict

import torch
import torch.nn.functional as F
# from sentry_sdk.utils import epoch
# from setuptools.sandbox import save_path
# from pyexpat import features

# from markdown_it.common.html_re import attr_name
from torch import nn
from torch.amp import autocast, GradScaler
from .utils import SoftMatchWeightingHook
# from semilearn.core.algorithmbase import AlgorithmBase
# from semilearn.core.utils import ALGORITHMS, send_model_cuda
from hooks import PseudoLabelingHook, DistAlignEMAHook
# from semilearn.algorithms.utils import SSL_Argument, str2bool
from network.semireward import Rewarder, Generator, EMARewarder, cosine_similarity_n, label_dim, sr_decay
# from semilearn.core.algorithmbase import AlgorithmBase
from ..consistency import ConsistencyLoss
from ..base import Base


# @ALGORITHMS.register('srsoftmatch')
# class SRSoftMatch(AlgorithmBase):
class SRSoftMatch(Base):
    """
        SoftMatch algorithm (https://arxiv.org/abs/2301.10921)).
        SemiReward algorithm (https://arxiv.org/abs/2310.03013).

        Args:
            - args (`argparse`):
                algorithm arguments
            - net_builder (`callable`):
                network loading function
            - tb_log (`TBLog`):
                tensorboard logger.py
            - logger.py (`logging.Logger`):
                logger.py to use
            - T (`float`):
                Temperature for pseudo-label sharpening
            - hard_label (`bool`, *optional*, default to `False`):
                If True, targets have [Batch size] shape with int values. If False, the target is vector
            - ema_p (`float`):
                exponential moving average of probability update
        """

    # def __init__(self, model, args, net_builder = None, tb_log = None, logger.py = None):
    def __init__(self, model, rewarder, rewarder_optimizer, generator, generator_optimizer, args):
        # super().__init__(args, net_builder, tb_log, logger.py)
        super().__init__()
        self.init(T = args.T, hard_label = args.use_hard_label, dist_align = args.dist_align,
                  dist_uniform = args.dist_uniform,
                  ema_p = args.ema_p, n_sigma = args.n_sigma, per_class = args.per_class,
                  it = args.it, epoch = args.epoch,
                  use_amp = args.use_amp, align_ratio = args.align_ratio,
                  save_path = args.save_path)
        self.N_k = args.N_k
        self.num_classes = 2
        self.gpu = args.gpu_id
        # self.device = torch.device('cuda:{}'.format(self.gpu) if torch.cuda.is_available() else 'cpu')
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        # 设置GPU设备
        # os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"
        device_ids = [0, 1]  # 你的GPU id 列表
        # 使用 DataParallel 包装模型

        # 用于计算奖励的模型label_embedding_dim维度测试16、32、64
        self.rewarder = rewarder
        # self.rewarder = Rewarder(label_dim(self.num_classes), 32,
        #         #                          args.feature_dim).to(self.device) if args.sr_ema == 0 else EMARewarder(
        #         #     label_dim(self.num_classes), 128, feature_dim = args.feature_dim,
        #         #     ema_decay = args.sr_ema_m).cuda()
        # self.rewarder = nn.DataParallel(self.rewarder, device_ids = device_ids)

        # 生成伪标签的模型
        self.generator = generator
        # self.generator = Generator(args.feature_dim).cuda()
        # self.generator = nn.DataParallel(self.generator, device_ids = device_ids)

        self.start_timing = args.start_timing

        # todo 添加优化器
        # self.lambda_u = nn.Parameter(torch.tensor(args.lambda_u))
        self.lambda_u = args.lambda_u

        # 分别用于训练 rewarder 和 generator 的 Adam 优化器
        # self.rewarder_optimizer = torch.optim.Adam(self.rewarder.parameters(), lr = args.reward_lr)
        # self.generator_optimizer = torch.optim.Adam(self.generator.parameters(), lr = args.reward_lr)
        self.rewarder_optimizer = rewarder_optimizer
        self.generator_optimizer = generator_optimizer
        # self.lambda_u_optimizer = torch.optim.Adam(self.lambda_u, lr = args.reward_lr)

        # lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(self.rewarder_optimizer, T_0 = 15,
        #                                                                     T_mult = 2)
        # lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(self.generator_optimizer, T_0 = 15,
        #                                                                     T_mult = 2)

        # 用于训练的损失函数，使用的是均方误差损失
        self.criterion = torch.nn.MSELoss()

        # 跟踪训练过程中最大的奖励值，用于确保选取最自信的伪标签
        self.max_reward = -float('inf')

        self.model = model
        self.ce_loss = nn.BCEWithLogitsLoss()
        self.amp_cm = autocast if self.use_amp else contextlib.nullcontext
        # self.call_hook = SoftMatchWeightingHook.call_hook
        # self.register_hook = SoftMatchWeightingHook.register_hook
        self.consistency_loss = ConsistencyLoss()
        # self.process_out_dict = Base.process_out_dict
        # self.process_log_dict = Base.process_log_dict
        self.hooks_dict = OrderedDict()
        # self.get_save_dict = Base.get_save_dict
        # self.lambda_diff = nn.Parameter(torch.tensor(0.1))

        # self.old_it = args.old_it
        self.filtered_pseudo_labels = None
        self.filtered_feats_x_ulb_w = None
        self.prob_max_mu_t = args.prob_max_mu_t
        self.prob_max_var_t = args.prob_max_var_t
        self.model_load = args.model_load
        self.model_load_state = args.model_load_state
        self.set_hooks()


    def init(self, T, hard_label = True, dist_align = True, dist_uniform = False, ema_p = 0.999, n_sigma = 2,
             per_class = False, it = 1, epoch = 100, use_amp = True, align_ratio = 0.3,
             save_path = None):
        self.T = T  # 伪标签软化过程中使用
        self.use_hard_label = hard_label  # 是否使用硬标签
        self.dist_align = dist_align  # 分布对齐策略
        self.dist_uniform = dist_uniform
        self.ema_p = ema_p  # 指数滑动平均的参数
        self.n_sigma = n_sigma
        self.per_class = per_class
        self.epoch = epoch
        # self.lambda_u = lambda_u
        self.it = it
        self.use_amp = use_amp
        self.align_ratio = align_ratio
        self.save_path = save_path

    # 生成无监督损失。通过伪标签和rewarder模型计算损失
    # def data_generator(self, x_lb, y_lb, x_ulb_w, x_ulb_s, rewarder, gpu):
    def data_generator(self, pred_x_ulb_s, attn_x_ulb_s, feat_x_ulb_w, pred_x_ulb_w, rewarder):
    # def data_generator(self, x_ulb_a_w, x_ulb_b_w, x_ulb_a_s, x_ulb_b_s, rewarder):
        rewarder.eval()
        unsup_losss = None
        rewards = None
        # sr_decay()在SemiReward中，奖励正向衰减比率（rewarder forward decay ratio）
        for _ in range(sr_decay(self.epoch, self.it)):
            # num_lb = y_lb.shape[0]
            # with self.amp_cm(device_type = "cuda", dtype = torch.float32):
            with self.amp_cm(device_type = "cuda"):
                # if self.use_cat:
                #     inputs = torch.cat((x_lb, x_ulb_w, x_ulb_s))
                #     outputs = self.model(inputs)
                #     logits_x_ulb_w, logits_x_ulb_s = outputs['logits'][num_lb:].chunk(2)
                #     feats_x_ulb_w, feats_x_ulb_s = outputs['feat'][num_lb:].chunk(2)
                # else:
                #     outs_x_ulb_s = self.model(x_ulb_s)
                #     logits_x_ulb_s = outs_x_ulb_s['logits']
                #     feats_x_ulb_s = outs_x_ulb_s['feat']
                #     with torch.no_grad():
                #         outs_x_ulb_w = self.model(x_ulb_w)
                #         logits_x_ulb_w = outs_x_ulb_w['logits']
                #         feats_x_ulb_w = outs_x_ulb_w['feat']

                # 强增强
                # feat_x_ulb_s, pred_x_ulb_s, attn_x_ulb_s, diff_combined_ulb_s = outs_x_ulb_s
                # feat_x_ulb_s, pred_x_ulb_s, attn_x_ulb_s = outs_x_ulb_s

                # 弱增强
                # feat_x_ulb_w, pred_x_ulb_w, attn_x_ulb_w, diff_combined_ulb_w = outs_x_ulb_w
                # feat_x_ulb_w, pred_x_ulb_w = outs_x_ulb_w[0], outs_x_ulb_w[1]
                # outs_x_ulb_s = self.model(x_ulb_a_s, x_ulb_b_s)
                # feat_x_ulb_s, pred_x_ulb_s, attn_x_ulb_s, diff_combined_ulb_s = outs_x_ulb_s
                # pred_x_ulb_s, attn_x_ulb_s = outs_x_ulb_s[1], outs_x_ulb_s[2]
                # with torch.no_grad():
                #     outs_x_ulb_w = self.model(x_ulb_a_w, x_ulb_b_w)
                    # feat_x_ulb_w, pred_x_ulb_w, attn_x_ulb_w, diff_combined_ulb_w = outs_x_ulb_w
                    # feat_x_ulb_w, pred_x_ulb_w = outs_x_ulb_w[0], outs_x_ulb_w[1]

                probs_x_ulb_w = torch.sigmoid(pred_x_ulb_w.detach())
                # probs_x_ulb_w = self.compute_prob(logits_x_ulb_w.detach())
                # pseudo_label = self.call_hook("gen_ulb_targets", "PseudoLabelingHook",
                #                               logits = probs_x_ulb_w,
                #                               use_hard_label = self.use_hard_label,
                #                               T = self.T,
                #                               softmax = False,
                #                               threshold = 0.5)
                # SoftMatch可学习的截断高斯加权。
                mask = self.call_hook("masking", "MaskingHook", logits_x_ulb = probs_x_ulb_w, softmax_x_ulb = False)
                with torch.no_grad():
                    reward = rewarder(feat_x_ulb_w.detach(), probs_x_ulb_w.squeeze(1))
                avg_reward = reward.mean()
                # mask2 = torch.where(reward >= avg_reward, torch.tensor(1).to(self.device),
                #                     torch.tensor(0).to(self.device)).squeeze().float()
                mask2 = (reward >= avg_reward).long().float().to(self.device)
                # unsup_loss维度[batch_size, height, width]
                unsup_loss = (self.consistency_loss(pred_x_ulb_s, probs_x_ulb_w, 'ce', mask = mask,
                                                    mask2 = mask2) + self.consistency_loss(attn_x_ulb_s,
                                                                                           probs_x_ulb_w,
                                                                                           'ce', mask = mask,
                                                                                           mask2 = mask2))
        #         # unsup_loss = unsup_loss
        # num_lb = y_lb.shape[0]
        # with self.amp_cm(device_type = "cuda", dtype = torch.float32):
        # with self.amp_cm(device_type = "cuda"):
        # if self.use_cat:
        #     inputs = torch.cat((x_lb, x_ulb_w, x_ulb_s))
        #     outputs = self.model(inputs)
        #     logits_x_ulb_w, logits_x_ulb_s = outputs['logits'][num_lb:].chunk(2)
        #     feats_x_ulb_w, feats_x_ulb_s = outputs['feat'][num_lb:].chunk(2)
        # else:
        #     outs_x_ulb_s = self.model(x_ulb_s)
        #     logits_x_ulb_s = outs_x_ulb_s['logits']
        #     feats_x_ulb_s = outs_x_ulb_s['feat']
        #     with torch.no_grad():
        #         outs_x_ulb_w = self.model(x_ulb_w)
        #         logits_x_ulb_w = outs_x_ulb_w['logits']
        #         feats_x_ulb_w = outs_x_ulb_w['feat']
        # 强增强
        # feat_x_ulb_s, pred_x_ulb_s, attn_x_ulb_s, diff_combined_ulb_s = outs_x_ulb_s
        # feat_x_ulb_s, pred_x_ulb_s, attn_x_ulb_s = outs_x_ulb_s
        # 弱增强
        # feat_x_ulb_w, pred_x_ulb_w, attn_x_ulb_w, diff_combined_ulb_w = outs_x_ulb_w
        # feat_x_ulb_w, pred_x_ulb_w = outs_x_ulb_w[0], outs_x_ulb_w[1]
        # outs_x_ulb_s = self.model(x_ulb_a_s, x_ulb_b_s)
        # feat_x_ulb_s, pred_x_ulb_s, attn_x_ulb_s, diff_combined_ulb_s = outs_x_ulb_s
        # pred_x_ulb_s, attn_x_ulb_s = outs_x_ulb_s[1], outs_x_ulb_s[2]
        # with torch.no_grad():
        # outs_x_ulb_w = self.model(x_ulb_a_w, x_ulb_b_w)
        # feat_x_ulb_w, pred_x_ulb_w, attn_x_ulb_w, diff_combined_ulb_w = outs_x_ulb_w
        # feat_x_ulb_w, pred_x_ulb_w = outs_x_ulb_w[0], outs_x_ulb_w[1]
        # probs_x_ulb_w = torch.sigmoid(pred_x_ulb_w.detach())
        # probs_x_ulb_w = self.compute_prob(logits_x_ulb_w.detach())
        # pseudo_label = self.call_hook("gen_ulb_targets", "PseudoLabelingHook",
        #                               logits = probs_x_ulb_w,
        #                               use_hard_label = self.use_hard_label,
        #                               T = self.T,
        #                               softmax = False,
        #                               threshold = 0.5)
        # SoftMatch可学习的截断高斯加权。
        # mask = self.call_hook("masking", "MaskingHook", logits_x_ulb = probs_x_ulb_w, softmax_x_ulb = False)
        # reward = rewarder(feat_x_ulb_w.detach(), pseudo_label)
        # avg_reward = reward.mean()
        # mask2 = torch.where(reward >= avg_reward, torch.tensor(1).to(self.device),
        #                     torch.tensor(0).to(self.device)).squeeze().float()
        # unsup_loss维度[batch_size, height, width]
        # unsup_loss = (self.consistency_loss(pred_x_ulb_s, pseudo_label.float(), 'ce', mask = mask,
        #                                     mask2 = mask2) + self.consistency_loss(attn_x_ulb_s,
        #                                                                            pseudo_label.float(),
        #                                                                            'ce', mask = mask,
        #                                                                            mask2 = mask2))
        # unsup_loss = unsup_loss
        return unsup_loss

    # 注册了多个“钩子”（自定义操作）来支持算法训练中的特定任务
    def set_hooks(self):
        # 生成无标签数据的伪标签
        self.register_hook(PseudoLabelingHook(), "PseudoLabelingHook")
        # 通过 EMA (Exponential Moving Average) 对齐模型输出分布
        self.register_hook(DistAlignEMAHook(
            num_classes = self.num_classes, momentum = self.ema_p, align_ratio = self.align_ratio,
            p_target_type = 'uniform' if self.dist_uniform else 'model'),
            "DistAlignHook")
        # 根据权重调整伪标签的质量
        self.register_hook(SoftMatchWeightingHook(
            num_classes = self.num_classes, n_sigma = self.n_sigma, momentum = self.ema_p,
            per_class = self.per_class, prob_max_mu_t = self.prob_max_mu_t, prob_max_var_t = self.prob_max_var_t),
            "MaskingHook")
        # super().set_hooks()

    def get_save_dict(self, load_path):
        save_epoch = self.it
        print('save_epoch', save_epoch)
        generator_dir = os.path.join(load_path, 'generator.pth')
        rewarder_dir = os.path.join(load_path, 'rewarder.pth')
        softmatch_dir = os.path.join(load_path, 'softmatch.pth')

        # 1. 先建立一个字典，保存三个参数：

        rewarder_state = {'rewarder_model': self.rewarder.module.state_dict() if isinstance(self.rewarder,
                                                                                            torch.nn.DataParallel) else self.rewarder.state_dict(),
                          'optimizer': self.rewarder_optimizer.state_dict(),
                          'epoch': self.it}
        generator_state = {'generator_model': self.generator.module.state_dict() if isinstance(self.generator,
                                                                                               torch.nn.DataParallel) else self.generator.state_dict(),
                           'optimizer': self.generator_optimizer.state_dict(),
                           'epoch': self.it}
        # assert self.hooks_dict['DistAlignHook'].p_model is not None, "p_model is None"
        # assert self.hooks_dict['DistAlignHook'].p_target is not None, "p_target is None"
        assert self.hooks_dict['MaskingHook'].prob_max_mu_t is not None, "prob_max_mu_t is None"
        assert self.hooks_dict['MaskingHook'].prob_max_var_t is not None, "prob_max_var_t is None"
        softmatch_state = {
            'p_model': self.hooks_dict['DistAlignHook'].p_model,
            'p_target': self.hooks_dict['DistAlignHook'].p_target,
            'prob_max_mu_t': self.hooks_dict['MaskingHook'].prob_max_mu_t,
            'prob_max_var_t': self.hooks_dict['MaskingHook'].prob_max_var_t,
        }
        # 2.调用torch.save():其中dir表示保存文件的绝对路径+保存文件名，如'/home/qinying/Desktop/modelpara.pth'
        torch.save(rewarder_state, rewarder_dir)
        torch.save(generator_state, generator_dir)
        torch.save(softmatch_state, softmatch_dir)
        # torch.save(ema_net.state_dict(),
        #            save_path + '_train1_' + '_best_teacher_iou.pth')  # 当student的精度最高的时候，同时存teacher的精度，然后用teacher的精度进行测试

    def load_model(self, load_path):
        # 假设你已经初始化了 model 和 optimizer
        generator_checkpoint = torch.load(os.path.join(load_path, 'generator.pth'), weights_only = True)
        rewarder_checkpoint = torch.load(os.path.join(load_path, 'rewarder.pth'), weights_only = True)
        softmatch_checkpoint = torch.load(os.path.join(load_path, 'softmatch.pth'), weights_only = True)
        # device_ids = [0, 1]
        # generator_checkpoint = nn.DataParallel(generator_checkpoint, device_ids = device_ids)
        # rewarder_checkpoint = nn.DataParallel(rewarder_checkpoint, device_ids = device_ids)

        # 恢复模型状态
        self.generator.load_state_dict(generator_checkpoint['generator_model'])
        self.rewarder.load_state_dict(rewarder_checkpoint['rewarder_model'])

        # 恢复优化器状态
        self.generator_optimizer.load_state_dict(generator_checkpoint['optimizer'])
        self.rewarder_optimizer.load_state_dict(rewarder_checkpoint['optimizer'])

        # 恢复 epoch 和其他信息
        self.hooks_dict['DistAlignHook'].p_model = softmatch_checkpoint['p_model'].to(self.device)
        self.hooks_dict['DistAlignHook'].p_target = softmatch_checkpoint['p_target'].to(self.device)
        self.hooks_dict['MaskingHook'].prob_max_mu_t = softmatch_checkpoint['prob_max_mu_t'].to(self.device)
        self.hooks_dict['MaskingHook'].prob_max_var_t = softmatch_checkpoint['prob_max_var_t'].to(self.device)
        print(f"load model complete!")
        # self.it = generator_checkpoint['epoch']
        # self.it = rewarder_checkpoint['epoch']

    def train_step(self, x_lb_a = None, x_lb_b = None, mask = None, with_label = None, x_ulb_a_w = None,
                   x_ulb_b_w = None,
                   x_ulb_a_s = None, x_ulb_b_s = None, total = 0, i = 0):
        # x_lb: 有标签数据
        # y_lb: 有标签数据的标签
        # x_ulb_w: 无标签的弱增强数据
        # x_ulb_s: 无标签的强增强数据
        # num_lb: 有标签数据的数量
        # num_lb = y_lb.shape[0]

        x_lb_a, x_lb_b = x_lb_a[with_label].to(self.device), x_lb_b[with_label].to(self.device)
        y_lb = mask[with_label].to(self.device)

        # 对C2F模型生成的无标签数据进行弱增强、强增强
        x_ulb_a_w, x_ulb_b_w = x_ulb_a_w[~with_label].to(self.device), x_ulb_b_w[~with_label].to(self.device)
        # mask_ulb_w = mask_ulb_w[~with_label].to(device)
        x_ulb_a_s, x_ulb_b_s = x_ulb_a_s[~with_label].to(self.device), x_ulb_b_s[~with_label].to(self.device)
        threshold = 0.5
        generator_loss = torch.zeros(1).to(self.device)
        rewarder_loss = torch.zeros(1).to(self.device)

        if self.model_load and self.model_load_state:
            self.load_model(self.save_path)
            self.model_load_state = False

        # inference and calculate sup/unsup losses
        # 计算有标签（supervised）和无标签（unsupervised）数据的损失
        # with self.amp_cm(device_type = "cuda",dtype = torch.float32):  # 混合精度训练上下文管理器
        with self.amp_cm(device_type = "cuda"):
            # if self.use_cat:
            #     inputs = torch.cat((x_lb, x_ulb_w, x_ulb_s))
            #     outputs = self.model(inputs)
            #     logits_x_lb = outputs['logits'][:num_lb]
            #     logits_x_ulb_w, logits_x_ulb_s = outputs['logits'][num_lb:].chunk(2)
            #     feats_x_lb = outputs['feat'][:num_lb]
            #     feats_x_ulb_w, feats_x_ulb_s = outputs['feat'][num_lb:].chunk(2)
            # else:
            #     outs_x_lb = self.model(x_lb)
            #     logits_x_lb = outs_x_lb['logits']
            #     feats_x_lb = outs_x_lb['feat']
            #     outs_x_ulb_s = self.model(x_ulb_s)
            #     logits_x_ulb_s = outs_x_ulb_s['logits']
            #     feats_x_ulb_s = outs_x_ulb_s['feat']
            #     with torch.no_grad():
            #         outs_x_ulb_w = self.model(x_ulb_w)
            #         logits_x_ulb_w = outs_x_ulb_w['logits']
            #         feats_x_ulb_w = outs_x_ulb_w['feat']
            # pred_x_lb[batch_size, 1，256, 256]
            # if self.it > 5:
            # outs_x_ulb_s = self.model(x_ulb_a_s, x_ulb_b_s)
            # feat_x_ulb_s, pred_x_ulb_s, attn_x_ulb_s, diff_combined_ulb_s = outs_x_ulb_s
            # feat_x_ulb_s, pred_x_ulb_s, attn_x_ulb_s = outs_x_ulb_s
            if self.it >= self.start_timing:
                feat_x_ulb_s, pred_x_ulb_s, attn_x_ulb_s = self.model(x_ulb_a_s, x_ulb_b_s)
                with torch.no_grad():
                    # outs_x_ulb_w = self.model(x_ulb_a_w, x_ulb_b_w)
                    # feat_x_ulb_w, pred_x_ulb_w, attn_x_ulb_w, diff_combined_ulb_w = outs_x_ulb_w
                    feat_x_ulb_w, pred_x_ulb_w, _ = self.model(x_ulb_a_w, x_ulb_b_w)
                # feat_x_ulb_w, pred_x_ulb_w = outs_x_ulb_w[0], outs_x_ulb_w[1]
                # 矩阵每个值为像素点变化的可能性，维度[batch_size, 1, height, width]
                probs_x_ulb_w = torch.sigmoid(pred_x_ulb_w.detach())
                # if x_lb_a.shape[0] != 0:
            if with_label.any():
                # outs_x_lb = self.model(x_lb_a, x_lb_b)
                # feat_x_lb, pred_x_lb, attn_x_lb, diff_combined_lb = outs_x_lb
                feat_x_lb, pred_x_lb, attn_x_lb = self.model(x_lb_a, x_lb_b)

                # 矩阵每个值为像素点变化的可能性，维度[batch_size, 1, height, width]
                probs_x_lb = torch.sigmoid(pred_x_lb.detach())
            # if x_lb_a.shape[0] == 0:
            else:
                feat_x_lb = None
                pred_x_lb = None
                # 矩阵每个值为像素点变化的可能性，维度[batch_size, 1, height, width]
                probs_x_lb = None
            # if self.it > 5:
            #     feat_dict = {'x_lb': feat_x_lb, 'x_ulb_w': feat_x_ulb_w, 'x_ulb_s': feat_x_ulb_s}
            # else:
            #     feat_dict = {'x_lb': feat_x_lb}
            # feat_dict = {'x_lb': feat_x_lb, 'x_ulb_w': feat_x_ulb_w, 'x_ulb_s': feat_x_ulb_s}

            # probs_x_ulb_s = torch.sigmoid(pred_x_ulb_s.detach())
            # 全监督损失维度[batch_size, height, width]
            # if x_lb_a.shape[0] != 0:
            if with_label.any():
                sup_loss = self.ce_loss(pred_x_lb.squeeze(1), y_lb.squeeze(1)) + self.ce_loss(attn_x_lb.squeeze(1),
                                                                                              y_lb.squeeze(1))
            # if x_lb_a.shape[0] == 0:
            else:
                sup_loss = torch.zeros(1).to(self.device)
            sup_loss = torch.nan_to_num(sup_loss, nan = 0.0)

            # if 5 <= self.it < self.start_timing:
            # if self.start_timing <= self.it and self.it < self.start_timing + 5:
            #     #     # if x_lb_a.shape[0] == 0:
            #     if with_label.any():
            #         # probs_x_lb = torch.zeros(pred_x_ulb_w.shape).to(self.device)
            #         # uniform distribution alignment
            #         # 均匀分布对齐，维度[batch_size, num_classes, height, width]
            #         probs_x_ulb_w = self.call_hook("dist_align", "DistAlignHook", probs_x_ulb = probs_x_ulb_w,
            #                                        epoch = self.it)
            #     else:
            #         probs_x_ulb_w = self.call_hook("dist_align", "DistAlignHook", probs_x_ulb = probs_x_ulb_w,
            #                                        epoch = self.it,
            #                                        probs_x_lb = y_lb)
            if self.it >= self.start_timing:
                # calculate weight
                # 计算权重，SoftMatch可学习的截断高斯加权。维度[batch_size, height, width]
                # 基于模型的输出概率（例如无标签数据的预测）来计算加权掩码，用于在训练过程中对无标签数据进行加权处理
                mask = self.call_hook("masking", "MaskingHook", logits_x_ulb = probs_x_ulb_w, softmax_x_ulb = False)
                # if self.it > 5:
                # generate unlabeled targets using pseudo label hook
                # 使用伪标签钩子生成无标签数据伪标签，pseudo_label维度[batch_size, 1, height, width]
                # todo 可优化使用置信度
                # pseudo_label = self.call_hook("gen_ulb_targets", "PseudoLabelingHook",
                #                               # make sure this is logits, not dist aligned probs
                #                               # uniform alignment in softmatch do not use aligned probs for generating pseudo labels
                #                               logits = pred_x_ulb_w,
                #                               use_hard_label = self.use_hard_label,
                #                               T = self.T,
                #                               threshold = threshold)

            # SemiReward inference
            # 半监督奖励推理
            if self.it >= self.start_timing:  # 当前迭代次数self.it大于self.start_timing
                rewarder = self.rewarder
                unsup_loss = self.data_generator(pred_x_ulb_s, attn_x_ulb_s, feat_x_ulb_w, pred_x_ulb_w,
                                                 rewarder)  # 无监督损失
                # unsup_loss = self.data_generator(x_ulb_a_w, x_ulb_b_w, x_ulb_a_s, x_ulb_b_s, rewarder)  # 无监督损失
                #
                # with self.amp_cm(device_type = "cuda", dtype = torch.float32):
                with self.amp_cm(device_type = "cuda"):
                    self.rewarder.eval()
                    with torch.no_grad():
                        reward = self.rewarder(feat_x_ulb_w.detach(), probs_x_ulb_w.squeeze(1))
                    avg_reward = reward.mean()
                    self.max_reward = max(self.max_reward, avg_reward)

                    # 根据奖励值过滤伪标签、高奖励值特征
                    if avg_reward > self.max_reward:
                        del self.filtered_pseudo_labels
                        del self.filtered_feats_x_ulb_w
                        torch.cuda.empty_cache()

                        self.filtered_pseudo_labels = probs_x_ulb_w.detach()
                        self.filtered_feats_x_ulb_w = feat_x_ulb_w.detach()

                    # mask2 = torch.where(reward >= avg_reward, torch.tensor(1).to(self.device),
                    #                     torch.tensor(0).to(self.device)).squeeze().float()
                    # mask2 = (reward >= avg_reward).float().to(self.device)

                unsup_loss = torch.nan_to_num(unsup_loss, nan = 0.0)
            else:
                unsup_loss = torch.zeros(1).to(self.device)
                # if 5 <= self.it < self.start_timing:
                # if self.it < self.start_timing:
                #     unsup_loss = self.consistency_loss(pred_x_ulb_s, pseudo_label.float(), 'ce',
                #                                        mask = mask) + self.consistency_loss(attn_x_ulb_s,
                #                                                                             pseudo_label.float(),
                #                                                                             'ce', mask = mask)  # 无监督损失
                #     unsup_loss = torch.nan_to_num(unsup_loss, nan = 0.0)
        # SemiReward training
        # 半监督奖励训练
        if self.it >= 0:  # 当前迭代次数
            # Generate pseudo labels using the generator (your pseudo-labeling process)
            # 使用生成器（您的伪标签生成过程）来生成伪标签

            # if self.it > self.start_timing:
            #     with self.amp_cm(device_type = "cuda"):
            #         # filtered_pseudo_labels = pseudo_label.long()
            #
            #         self.rewarder.eval()
            #         reward = self.rewarder(feat_x_ulb_w.detach(), pseudo_label.squeeze(1))
            #         reward = reward.mean()
            #         self.max_reward = torch.where(reward > self.max_reward, reward, self.max_reward)

            # 如果在初始训练阶段，生成和计算伪标签与真实标签的余弦相似度，并计算生成器和奖励器的损失，进行反向传播和优化。
            if self.it < self.start_timing:
                if x_lb_a.shape[0] != 0:
                    # 设置为训练模式
                    self.rewarder.train()
                    self.generator.train()
                    with self.amp_cm(device_type = "cuda"):
                        generated_label = self.generator(feat_x_lb.detach())  # 维度[batch_size, 1, height, width]
                        generated_label = (generated_label > threshold).long()  # 使用阈值（如0.5）将概率转换为硬标签（0或1）
                        # generated_label = generated_label.long()
                        # Convert generated pseudo labels and true labels to tensors
                        # 将生成的伪标签标签和真实转换为张量
                        real_labels_tensor = y_lb.to(self.device).squeeze(1)
                        real_labels_tensor = real_labels_tensor.long()
                        # 计算奖励值，维度 [batch_size, height, width]，每个像素点对应的奖励值。
                        reward = self.rewarder(feat_x_lb.detach(), generated_label.squeeze(1))
                        # 当前迭代次数超过起始计时 self.start_timing，则根据奖励值过滤伪标签
                        # 独热矩阵维度[batch_size, height, width, num_classes]
                        generated_label = F.one_hot(generated_label.squeeze(1), num_classes = self.num_classes)
                        real_labels_tensor = F.one_hot(real_labels_tensor, num_classes = self.num_classes)
                        cosine_similarity_score = cosine_similarity_n(generated_label.float(),
                                                                      real_labels_tensor.float())
                        generator_loss = self.criterion(reward, torch.ones_like(reward).to(self.device))
                        rewarder_loss = self.criterion(reward, cosine_similarity_score)
                        generator_loss = torch.nan_to_num(generator_loss, nan = 0.0)
                        rewarder_loss = torch.nan_to_num(rewarder_loss, nan = 0.0)
                    self.generator_optimizer.zero_grad()
                    self.rewarder_optimizer.zero_grad()
                    generator_loss.backward(retain_graph = True)
                    rewarder_loss.backward(retain_graph = True)
                    self.generator_optimizer.step()
                    self.rewarder_optimizer.step()
                    # 调整学习率
                    # lr_scheduler.step()
                    # 每隔 N_k 次迭代，重置 max_reward 并训练生成器和奖励器
                    # 计算生成器和奖励器的损失，并进行反向传播和优化
            if self.it % self.N_k == 0 and self.it >= self.start_timing and self.filtered_feats_x_ulb_w is not None and self.filtered_pseudo_labels is not None:
                with self.amp_cm(device_type = "cuda"):
                    self.max_reward = -float('inf')  # 重置 max_reward
                    self.rewarder.train()
                    self.generator.train()
                    generated_label = self.generator(self.filtered_feats_x_ulb_w)
                    generated_label = (generated_label > threshold).long()  # 使用阈值（如0.5）将概率转换为硬标签（0或1）
                    # generated_label = generated_label.long()
                    reward = self.rewarder(self.filtered_feats_x_ulb_w, generated_label.squeeze(1))
                    # 独热矩阵维度[batch_size, height, width, num_classes]
                    generated_label = F.one_hot(generated_label.squeeze(1), num_classes = self.num_classes)
                    filtered_pseudo_labels = F.one_hot(self.filtered_pseudo_labels, num_classes = self.num_classes)
                    # 计算每个像素点余弦相似度分数，维度[batch_size, height, width]
                    cosine_similarity_score = cosine_similarity_n(generated_label.float(),
                                                                  filtered_pseudo_labels.float())
                    # 计算reward和全1张量之间的损失，即期望奖励器的输出尽可能接近1
                    generator_loss = self.criterion(reward, torch.ones_like(reward).cuda(self.gpu))
                    rewarder_loss = self.criterion(reward, cosine_similarity_score)
                    generator_loss = torch.nan_to_num(generator_loss, nan = 0.0)
                    rewarder_loss = torch.nan_to_num(rewarder_loss, nan = 0.0)
                self.generator_optimizer.zero_grad()
                self.rewarder_optimizer.zero_grad()
                generator_loss.backward(retain_graph = True)
                rewarder_loss.backward(retain_graph = True)
                self.generator_optimizer.step()
                self.rewarder_optimizer.step()
                self.get_save_dict(self.save_path)
                print(f"Epoch {self.it} saved at last iteration!")
        # 半监督系数lambda_u有待测试暂设置为1
        # print(f'半监督系数lambda_u = {self.lambda_u}')
        total_loss = sup_loss + self.lambda_u * unsup_loss
        if self.it >= self.start_timing:
            out_dict = self.process_out_dict(total_loss = total_loss, probs_x_lb = probs_x_lb,
                                             probs_x_ulb_w = torch.sigmoid(pred_x_ulb_w.detach()))
            log_dict = self.process_log_dict(sup_loss = sup_loss.item(),
                                             unsup_loss = unsup_loss.item(),
                                             total_loss = total_loss.item(),
                                             util_ratio = mask.float().mean().item(),
                                             generator_loss = generator_loss.item(),
                                             rewarder_loss = rewarder_loss.item(),
                                             lambda_u = self.lambda_u)
        else:
            out_dict = self.process_out_dict(total_loss = total_loss, probs_x_lb = probs_x_lb)
            log_dict = self.process_log_dict(sup_loss = sup_loss.item(),
                                             unsup_loss = unsup_loss.item(),
                                             total_loss = total_loss.item(),
                                             generator_loss = generator_loss.item(),
                                             rewarder_loss = rewarder_loss.item(),
                                             lambda_u = self.lambda_u)
        # 判断是否是该轮训练的最后一次迭代
        if i == total - 1 and self.it < self.start_timing:
            # 在最后一次迭代后保存模型
            self.get_save_dict(self.save_path)
            # print(f"Epoch {self.it} saved at last iteration!")
        torch.cuda.empty_cache()
        return out_dict, log_dict

    # # TODO: change these
    # 返回一个字典，包含需要保存的模型状态信息
    # def get_save_dict(self):
    #     # save_dict = super().get_save_dict()
    #     save_dict = self.get_save_dict()
    #     # additional saving arguments
    #     save_dict['p_model'] = self.hooks_dict['DistAlignHook'].p_model.cpu()
    #     save_dict['p_target'] = self.hooks_dict['DistAlignHook'].p_target.cpu()
    #     save_dict['prob_max_mu_t'] = self.hooks_dict['MaskingHook'].prob_max_mu_t.cpu()
    #     save_dict['prob_max_var_t'] = self.hooks_dict['MaskingHook'].prob_max_var_t.cpu()
    #     return save_dict
    #
    # # 从磁盘加载模型的状态，并将附加的参数（如对齐分布的模型参数和伪标签最大值等）加载到模型中
    # def load_model(self, load_path):
    #     checkpoint = super().load_model(load_path)
    #     self.hooks_dict['DistAlignHook'].p_model = checkpoint['p_model'].cuda(self.args.gpu)
    #     self.hooks_dict['DistAlignHook'].p_target = checkpoint['p_target'].cuda(self.args.gpu)
    #     self.hooks_dict['MaskingHook'].prob_max_mu_t = checkpoint['prob_max_mu_t'].cuda(self.args.gpu)
    #     self.hooks_dict['MaskingHook'].prob_max_var_t = checkpoint['prob_max_var_t'].cuda(self.args.gpu)
    #     self.print_fn("additional parameter loaded")
    #     return checkpoint

    # 返回算法所需的所有命令行参数的定义
    # @staticmethod
    # def get_argument():
    #     return [
    #         SSL_Argument('--hard_label', str2bool, True),
    #         SSL_Argument('--T', float, 0.5),
    #         SSL_Argument('--dist_align', str2bool, True),
    #         SSL_Argument('--dist_uniform', str2bool, True),
    #         SSL_Argument('--ema_p', float, 0.999),
    #         SSL_Argument('--n_sigma', int, 2),
    #         SSL_Argument('--per_class', str2bool, False),
    #         SSL_Argument('--start_timing', int, 20000),
    #         SSL_Argument('--feature_dim', int, 384),
    #         SSL_Argument('--sr_lr', float, 0.0005),
    #         SSL_Argument('--N_k', int, 10),
    #         SSL_Argument('--sr_ema', str2bool, True),
    #         SSL_Argument('--sr_ema_m', float, 0.999),
    #     ]
